# Instructions  

  ## Steps
  1. Don't Panic! This code looks complex but I assure you there is nothing here that is very hard. If it makes you miserable to read this code it's fine. Go on to the non-flask option.
  2. Watch the videos (ignore the bit about forking, the education version does that automatically)
  3. First Run the code and play around with the website and add and edit the data
  4. Find the SQL statements in the code and make sure you understand them
  5. Use your web design skills from last year to style the pages much better than I have. 



  Watch this [Video tutorial 1](https://www.youtube.com/watch?v=FzavnNtfhv8)

  Watch this [Video tutorial 2] (https://www.youtube.com/watch?v=R9OU1yyVm0c)

  Watch this [Video tutorial 3] (https://www.youtube.com/watch?v=bdZlrVT61WY)


  