#import all the webserver stuff
from flask import Flask, render_template, request
#import the sqlite stuff
import sqlite3
#import json stuff
import json
import time
#the name of your app - we'll use this a bunch
app = Flask(__name__)


#when someone goes to /reset in the website...
@app.route('/reset')
#call the function reset_db()
def reset_db():
    #connect to the database
    conn = sqlite3.connect('database.db')
    #make a message that sayd "Opened the database successfully"
    msg = "Opened database successfully"
    #drop the table called animals -- allows you to change the table called "animals"
    conn = sqlite3.connect('database.db')
    conn.execute("DROP TABLE IF EXISTS planeCrashes;")
    #create the table called planeCrashes with the defined fields
    conn.execute(
        'CREATE TABLE planeCrashes(animal_id INTEGER PRIMARY KEY AUTOINCREMENT, date, "Location/operator", "Aircraft type/registration", fatalities);'
    )
    #add to the message with "Table created successfully"
    #the <br/> renders as a new line in HTML
    msg = msg + "<br\>Table created successfully"
    #close the connection to the database
    conn.close()
    #send back to the main flask webserver what it should do.
    return render_template('reset.html', msg=msg)


#when someone goes to the address /enternew on the website
@app.route('/enternew')
#call the function new_animal()
def new_animal():
    #which doesn't do anything but return what the webserver should do
    #go to the animal.html page
    return render_template('animal.html')


#when someone goes to the address /addrec on the website
#they could either be posting or getting (POST, put stuff there, GET, request stuff)
@app.route('/addrec', methods=['POST', 'GET'])
#call the function addrec
def addrec():
    #if they POSTed information --> that means they pressed submit on our animal.html page
    if request.method == 'POST':
        #make an empty message
        msg1 = ""
        #This is tricky, but it's just trapping errors for us.
        #try means, see if you get to the end of a series of steps and if
        #everything works then we're fine and if it doesn't
        #do the "except" steps and undo everything you did in the try section.

        try:
            #assign each of the pieces of information we receive to a new variable

            date = request.form['date']

            lo = request.form['lo']
            atr = request.form['atr']
            fat = request.form['fat']

            #print that to the screen
            print(date, lo, atr, fat)

            #connect to the db
            con = sqlite3.connect("database.db")
            #make a cursor which helps us do all the things
            cur = con.cursor()
            #execute the insert statement in SQL
            cur.execute(
                f"""INSERT INTO planeCrashes (date, 'Location/operator', 'Aircraft type/registration', fatalities) VALUES(?,?,?,?);""",
                (date, lo, atr, fat))

            #save the database change
            con.commit()
            #set message to say that it worked
            msg1 = "Record successfully added"
            #close th database
            con.close()
        except:
            #undo the attempted insertion
            con.rollback()
            #close th database
            con.close()
            #set message to say that it didn't work
            msg1 = "error in insert operation"

        #regardless of whether it worked or not do this bit
        finally:
            #return what the webserver should do next,
            #go to the result page with the msg variable as msg
            return render_template("result.html", msg=msg1)


#when someone goes to the address /list on the website
@app.route('/list')
#run the function get_list
def get_list():
    #connect to the db
    con = sqlite3.connect("database.db")
    #makes us able to reference each field by name
    con.row_factory = sqlite3.Row
    #make a cursor which helps us do all the things
    cur = con.cursor()
    #execute a select on the data in the database
    cur.execute(
        "select scientific_name, common_name, diet, habitat, vertebrate from animals"
    )
    #fetch all the records
    rows1 = cur.fetchall()
    #return what the webserver should do next,
    #go to the list page with the rows variable as rows
    return render_template("list.html", rows=rows1)


#when someone goes to the address / (i.e. the home page, no extra address)
@app.route('/')
#run the function home
def home():
    #which does nothing
    #but returns what the webserver should do next
    #go to the home page
    return render_template('home.html')


#when someone goes to the address /updatedata (this is for updating the data based on new json files uploaded to the folder jsonFiles)
@app.route('/updatedata')
#run the function updateData
def updateData():
    with open('./jsonFiles/1920.json', 'r') as j:
        con = sqlite3.connect("database.db")
        x = json.loads(j.read())
        json_data = x
        res = x
        #print(type(x));
        cnty = 1
        print(res)
        t = 1
        while t < len(res):
          v = 0
          while v < 4:
            print(v)
            print(t)
            try:
              res[v][t].replace(res[v][t], str(res[v][t].strip(']').strip('[').split(', ')));
            except:
              print("error")
            v += 1
          t += 1
        while cnty < 13:
          img = res[cnty]
          print(type(img))
          print("cnty "+str(cnty))
          #time.sleep(10)
          #print(type(res[0][cnty]))
          #print(len(res[0][cnty]))
          con.cursor().execute('INSERT INTO planeCrashes(date) VALUES(?);', (res[1][cnty]))
          con.cursor().execute('INSERT INTO planeCrashes("Location/operator") VALUES(?);', (res[2][cnty]))
          con.cursor().execute('INSERT INTO planeCrashes("Aircraft type/registration") VALUES(?);', (res[3][cnty]))
          con.cursor().execute('INSERT INTO planeCrashes(fatalities) VALUES(?);', (res[4][cnty]))
          cnty += 1
        con.commit()
        con.close()

    #con.cursor.executemany('INSERT INTO planecrashes(date, "Location/operator", "Aircraft type/registration", fatalities) VALUES(?,?,?,?);', (x,));


@app.route('/listnew')
def get_listnew():
    #connect to the db
    con = sqlite3.connect("database.db")
    #makes us able to reference each field by name
    con.row_factory = sqlite3.Row
    #make a cursor which helps us do all the things
    cur = con.cursor()
    #execute a select on the data in the database
    cur.execute(
        'select date, "Location/operator", "Aircraft type/registration", fatalities FROM planeCrashes;'
    )
    #fetch all the records
    rows1 = cur.fetchall()
    #return what the webserver should do next,
    #go to the list page with the rows variable as rows
    return render_template("list.html", rows=rows1)


#Check that this isn't being run by another module
if __name__ == '__main__':
    #run on the host 0.0.0.0
    app.run(debug=True, host='0.0.0.0')

#using the animal cards from https://aca.edu.au/resources/decision-trees-animal-trading-cards/
